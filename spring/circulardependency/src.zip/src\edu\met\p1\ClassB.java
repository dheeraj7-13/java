package edu.met.p1;

public class ClassB {
	ClassA a;
	public ClassB(ClassA a)
	{
		this.a=a;
	}
}
