package edu.met.p1;

public class ClassD {
	ClassC c;
	public ClassD() {
		// TODO Auto-generated constructor stub
		System.out.println("Contructor D");
	}
	public void setC(ClassC c)
	{
		System.out.println("Inside class D");
		this.c=c;
	}
}
