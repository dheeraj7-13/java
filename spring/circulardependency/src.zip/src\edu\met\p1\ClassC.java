package edu.met.p1;

public class ClassC {
	ClassD d;
	public ClassC()
	{
		System.out.println("Contructor C");
	}
	public void setD(ClassD d)
	{
		System.out.println("Inside class C");
		this.d=d;
	}
}
