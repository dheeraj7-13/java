package edu.met.p1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CircularTest {
	static ApplicationContext ctx;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ctx=new ClassPathXmlApplicationContext("AppCtx.xml");
		//ClassA a1=(ClassA) ctx.getBean("beanA");
		//ClassB b1=(ClassB) ctx.getBean("beanB");
		ClassC c1=(ClassC) ctx.getBean("beanC");
		ClassD d1=(ClassD) ctx.getBean("beanD");
	}

}
