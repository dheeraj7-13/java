package edu.met.p1;

public class ClassA {
	ClassB b;
	public ClassA(ClassB b)
	{
		this.b=b;
	}
}
